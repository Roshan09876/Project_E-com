import 'package:e_com/features/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';


void main() {
  // PopUpService.configure();
  runApp(ProviderScope(child:  MyApp()));
}
